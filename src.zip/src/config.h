#ifndef __CONFIG_H
#define __CONFIG_H

#define MAX_PLAYS 20	// Maximum number of plays allowed
#define MAX_SAMPLES 500 // Maximum number of frequencies allowed

#endif